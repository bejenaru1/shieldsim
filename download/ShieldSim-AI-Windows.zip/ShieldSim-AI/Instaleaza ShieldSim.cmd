@echo off
rem ShieldSim: instalare cu asistentul AI (Windows). Vezi CITESTE-MA.txt.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 pause
