﻿# ShieldSim installer (bootstrap). Run by "Instaleaza ShieldSim.cmd".
# Downloads the current launcher from the ShieldSim site into %LOCALAPPDATA%\ShieldSim and runs it
# with -Install: site files, Ollama, the AI model, shortcuts. Windows PowerShell 5.1 compatible.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
$Host.UI.RawUI.WindowTitle = 'Instalare ShieldSim'
$Dir = Join-Path $env:LOCALAPPDATA 'ShieldSim'
Write-Host ''
Write-Host '  ShieldSim - instalare cu asistentul AI (Nova)' -ForegroundColor Cyan
Write-Host '  Se instaleaza: site-ul, Ollama si modelul AI. Dureaza 10-30 de minute, in functie de internet.'
Write-Host '  Nu sunt necesare drepturi de administrator. Nu inchide aceasta fereastra.'
Write-Host ''
try {
  New-Item -ItemType Directory -Path $Dir -Force | Out-Null
  $launcher = Join-Path $Dir 'ShieldSim.ps1'
  Invoke-WebRequest -UseBasicParsing -Uri 'https://bejenaru1.github.io/shieldsim/download/win/ShieldSim.ps1' -OutFile $launcher -TimeoutSec 60
} catch {
  Write-Host "[ShieldSim] Nu pot descarca ShieldSim: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host '[ShieldSim] Verifica conexiunea la internet si porneste din nou instalarea.'
  Read-Host 'Apasa Enter ca sa inchizi'
  exit 1
}
# same console window, so the download progress of Ollama and the model is shown as it happens
$p = Start-Process powershell.exe -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$launcher`"", '-Install' -NoNewWindow -Wait -PassThru
exit $p.ExitCode
